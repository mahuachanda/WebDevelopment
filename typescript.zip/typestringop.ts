var msg:string = "hello"+"world" 
console.log(msg)