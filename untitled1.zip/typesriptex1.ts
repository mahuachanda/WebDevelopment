let name1:string = "John";
let score1:number = 50;
let score2:number = 42.50;
let sum = score1 + score2
console.log("name"+name1)
console.log("first score: "+score1)
console.log("second score: "+score2)
console.log("sum of the scores: "+sum)
