function hoist() {
    var message='Hoisting is all the rage!'
    console.log(message);
    return (message);


}

hoist();
