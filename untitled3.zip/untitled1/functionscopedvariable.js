function hoist() {
    console.log(message);
    var message='Hoisting is all the rage!'
}

hoist();